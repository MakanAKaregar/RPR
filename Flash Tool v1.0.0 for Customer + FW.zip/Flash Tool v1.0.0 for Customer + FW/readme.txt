Futher instructions to flash the custom firmware:

For the Adafruit products, connect the GPS shield to the Arduino, then load MySerialPassthrough.ino and finally simply connect the PC to Arduino -- the GPS will be visible through the Arduino. This way the USB-to-TTL cable is not needed.

Using FlashTool v1.0.0 (NOT ANY NEWER VERSION)

Series: 3329 [3339 is not available]

Download Agent: MTK_AllInOne_DA_MT3339_E3.bin

ROM: AXN2.10_5196_3339_1152.1111100.10.bin

ComPort: (varies)

Baudrate: 9600 (default)

Connect

"Download" [sic., it actually uploads the new firmware into the board]

See PDF doc for details.

THE NMEA BAUD RATE WILL BE CHANGED FROM 9600 TO 115200!

